package cl.negociospyme.barberia

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*

private val Black = Color(0xFF111111)
private val CardBlack = Color(0xFF1B1B1B)
private val Gold = Color(0xFFD4AF37)
private val SoftGold = Color(0xFFFFE8A3)
private val TextMuted = Color(0xFFB9B9B9)
private val Green = Color(0xFF4CAF50)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            BarberiaTheme {
                val nav = rememberNavController()
                NavHost(navController = nav, startDestination = "login") {
                    composable("login") { LoginScreen { nav.navigate("home") } }
                    composable("home") { HomeScreen(nav) }
                    composable("agenda") { SimpleListScreen("Agenda", agendaDemo, nav) }
                    composable("clientes") { SimpleListScreen("Clientes", clientesDemo, nav) }
                    composable("caja") { CajaScreen(nav) }
                    composable("barberos") { SimpleListScreen("Barberos", barberosDemo, nav) }
                    composable("servicios") { SimpleListScreen("Servicios", serviciosDemo, nav) }
                    composable("config") { ConfigScreen(nav) }
                }
            }
        }
    }
}

@Composable
fun BarberiaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold,
            secondary = SoftGold,
            background = Black,
            surface = CardBlack,
            onPrimary = Black,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

@Composable
fun LoginScreen(onLogin: () -> Unit) {
    var email by remember { mutableStateOf("admin@barberia.cl") }
    var pass by remember { mutableStateOf("123456") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Black)
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("BARBERÍA", color = Gold, fontSize = 36.sp, fontWeight = FontWeight.Black)
        Text("NegociosPyme", color = Color.White, fontSize = 18.sp)
        Spacer(Modifier.height(36.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Correo") },
            leadingIcon = { Icon(Icons.Default.Email, null) },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = pass,
            onValueChange = { pass = it },
            label = { Text("Contraseña") },
            leadingIcon = { Icon(Icons.Default.Lock, null) },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onLogin,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text("INGRESAR", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "Demo inicial · datos ficticios",
            color = TextMuted,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

data class Module(val title: String, val subtitle: String, val icon: ImageVector, val route: String)

private val modules = listOf(
    Module("Agenda", "Reservas y horarios", Icons.Default.CalendarMonth, "agenda"),
    Module("Clientes", "Historial y fidelización", Icons.Default.People, "clientes"),
    Module("Caja", "Ventas y medios de pago", Icons.Default.PointOfSale, "caja"),
    Module("Barberos", "Equipo y comisiones", Icons.Default.ContentCut, "barberos"),
    Module("Servicios", "Precios y duración", Icons.Default.Storefront, "servicios"),
    Module("Configuración", "Negocio, QR y plan", Icons.Default.Settings, "config")
)

@Composable
fun HomeScreen(nav: NavHostController) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Black),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Buenos días 👋", color = TextMuted, fontSize = 14.sp)
                    Text("Barbería Central", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                }
                Surface(shape = RoundedCornerShape(18.dp), color = Gold) {
                    Icon(Icons.Default.ContentCut, null, tint = Black, modifier = Modifier.padding(13.dp).size(28.dp))
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard("8", "Citas hoy", Modifier.weight(1f))
                StatCard("$84.000", "Ventas", Modifier.weight(1f))
                StatCard("3", "Barberos", Modifier.weight(1f))
            }
        }

        item {
            Text("Próxima cita", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = CardBlack,
                modifier = Modifier.fillMaxWidth().clickable { nav.navigate("agenda") }
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(12.dp), color = Gold.copy(alpha = .15f)) {
                        Text("13:30", color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Carlos González", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Corte + barba · Diego", color = TextMuted)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = Gold)
                }
            }
        }

        item {
            Text("Gestión", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        }

        items(modules.chunked(2)) { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                row.forEach { module ->
                    ModuleCard(module, Modifier.weight(1f)) { nav.navigate(module.route) }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        item {
            Surface(shape = RoundedCornerShape(18.dp), color = Gold.copy(alpha = .12f)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.QrCode2, null, tint = Gold, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("QR de reservas", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Comparte tu enlace para recibir nuevas citas", color = TextMuted, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(16.dp), color = CardBlack) {
        Column(Modifier.padding(14.dp)) {
            Text(value, color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(label, color = TextMuted, fontSize = 12.sp)
        }
    }
}

@Composable
fun ModuleCard(module: Module, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.height(130.dp).clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        color = CardBlack
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(module.icon, null, tint = Gold, modifier = Modifier.size(30.dp))
            Column {
                Text(module.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(module.subtitle, color = TextMuted, fontSize = 12.sp)
            }
        }
    }
}

private val agendaDemo = listOf(
    "13:30 · Carlos González · Corte + barba · Diego",
    "14:15 · Martín Pérez · Corte clásico · Sebastián",
    "15:00 · Felipe Soto · Degradado · Diego",
    "16:30 · Nicolás Rojas · Barba · Andrés"
)

private val clientesDemo = listOf(
    "Carlos González · 8 visitas · Última: 29/08",
    "Martín Pérez · 5 visitas · Última: 31/08",
    "Felipe Soto · 11 visitas · Cliente frecuente",
    "Nicolás Rojas · 3 visitas · Última: 27/08"
)

private val barberosDemo = listOf(
    "Diego · Activo · 40% comisión",
    "Sebastián · Activo · 40% comisión",
    "Andrés · Activo · 45% comisión"
)

private val serviciosDemo = listOf(
    "Corte clásico · $12.000 · 30 min",
    "Degradado · $14.000 · 45 min",
    "Barba · $8.000 · 20 min",
    "Corte + barba · $18.000 · 50 min"
)

@Composable
fun SimpleListScreen(title: String, data: List<String>, nav: NavHostController) {
    Scaffold(
        topBar = { AppTopBar(title, nav) },
        containerColor = Black,
        floatingActionButton = {
            FloatingActionButton(onClick = {}, containerColor = Gold) {
                Icon(Icons.Default.Add, null, tint = Black)
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(data) { item ->
                Surface(shape = RoundedCornerShape(16.dp), color = CardBlack, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Circle, null, tint = Green, modifier = Modifier.size(10.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(item, color = Color.White, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
                    }
                }
            }
        }
    }
}

@Composable
fun CajaScreen(nav: NavHostController) {
    Scaffold(topBar = { AppTopBar("Caja", nav) }, containerColor = Black) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("Resumen de hoy", color = TextMuted)
            Text("$84.000", color = Gold, fontSize = 38.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(18.dp))
            listOf(
                "Efectivo" to "$36.000",
                "Transferencia" to "$32.000",
                "Débito / Crédito" to "$16.000"
            ).forEach { (method, amount) ->
                Surface(shape = RoundedCornerShape(16.dp), color = CardBlack, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Row(Modifier.padding(16.dp)) {
                        Text(method, color = Color.White, modifier = Modifier.weight(1f))
                        Text(amount, color = Gold, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
            Button(onClick = {}, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                Icon(Icons.Default.AddShoppingCart, null)
                Spacer(Modifier.width(8.dp))
                Text("NUEVA VENTA")
            }
        }
    }
}

@Composable
fun ConfigScreen(nav: NavHostController) {
    Scaffold(topBar = { AppTopBar("Configuración", nav) }, containerColor = Black) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp)) {
            item {
                ConfigItem(Icons.Default.Store, "Datos de la barbería", "Nombre, logo, dirección y horarios")
                ConfigItem(Icons.Default.QrCode2, "QR de reservas", "Generar y compartir QR")
                ConfigItem(Icons.Default.Notifications, "Recordatorios", "Avisos automáticos de citas")
                ConfigItem(Icons.Default.CreditCard, "Plan y suscripción", "Estado del plan")
                ConfigItem(Icons.Default.Logout, "Cerrar sesión", "Salir de la cuenta")
            }
        }
    }
}

@Composable
fun ConfigItem(icon: ImageVector, title: String, subtitle: String) {
    Surface(shape = RoundedCornerShape(16.dp), color = CardBlack, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Gold)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold)
                Text(subtitle, color = TextMuted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTopBar(title: String, nav: NavHostController) {
    TopAppBar(
        title = { Text(title, fontWeight = FontWeight.Bold) },
        navigationIcon = {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.Default.ArrowBack, null)
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Black,
            titleContentColor = Color.White,
            navigationIconContentColor = Gold
        )
    )
}
